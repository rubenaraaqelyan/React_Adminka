import React from 'react';

const Switcher = () => {
    return (
        <div className="switcher-container">
            <div className="switcher active-switch">
                <div className="switcher-thumb" />
            </div>

            <p>У него есть такое-то право</p>
        </div>
    );
}

export default Switcher;